### My \[academic\] background

- [Software Engineering](/swe)

  - Apprenticeship Program
  - 2020-...

- [Computer Education and Instructional Technologies](https://bote.kku.edu.tr/)

  - Kirikkale University
  - Bachelor's Degree
  - 2010-2017

- [Physics](https://fizik.kku.edu.tr/)

  - Kirikkale University
  - _Dropout_
  - 2008-2010
