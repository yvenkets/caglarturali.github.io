### Certificates that I have earned over time

- [Full-Stack Web Development with React Specialization](https://www.coursera.org/account/accomplishments/specialization/certificate/XGPU5C68VAEE)

  - [Front-End Web UI Frameworks and Tools: Bootstrap 4](https://www.coursera.org/account/accomplishments/certificate/TQ2HAVM6JJ73)
  - [Front-End Web Development with React](https://www.coursera.org/account/accomplishments/certificate/QJPWRV28SCV3)
  - [Multiplatform Mobile App Development with React Native](https://www.coursera.org/account/accomplishments/certificate/GNX5WEXJWSGY)
  - [Server-Side Development with NodeJS, Express and MongoDB](https://www.coursera.org/account/accomplishments/certificate/XGMAYMHEXDZW)

- [freeCodeCamp | The Full Stack Development Certificate](https://guide.freecodecamp.org/certifications/)

  - [Responsive Web Design Certification](https://www.freecodecamp.org/certification/caglarturali/responsive-web-design)
  - [JavaScript Algorithms and Data Structures Certification](https://www.freecodecamp.org/certification/caglarturali/javascript-algorithms-and-data-structures)

- [Game Design and Development Specialization](https://www.coursera.org/specializations/game-development)

  - [Introduction to Game Development](https://www.coursera.org/account/accomplishments/certificate/GKDBNAGKPD6M)

- [Virtual Reality Specialization](https://www.coursera.org/specializations/virtual-reality)

  - [Introduction to Virtual Reality](https://www.coursera.org/account/accomplishments/certificate/UC3L666SD5TG)
  - [3D Models for Virtual Reality](https://www.coursera.org/account/accomplishments/certificate/4YHK3LYWMJPV)

- [Music Production Specialization](https://www.coursera.org/specializations/music-production)
  - [The Art of Music Production](https://www.coursera.org/account/accomplishments/certificate/DNVYLQQL3WVF)
  - [The Technology of Music Production](https://www.coursera.org/account/accomplishments/certificate/VZDUNEC24XER)
  - [Pro Tools Basics](https://www.coursera.org/account/accomplishments/certificate/YW4QY26UHC5F)
